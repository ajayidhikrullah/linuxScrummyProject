from django.apps import AppConfig


class AjayidhikrullahscrumyConfig(AppConfig):
    name = 'ajayidhikrullahscrumy'
